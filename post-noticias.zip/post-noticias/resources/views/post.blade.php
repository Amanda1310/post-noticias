@extends('partials.layout')

@section('content')
@include('partials.menu')
<div class="container">
    <div class="row mt-3">
        <div class="col-6">
            <h1>Posts</h1>
            @include('partials.errors')

            @if($post->id)
            <form action="{{ route('posts.update', ['id' => $post->id]) }}" method="post">
            {{ method_field('PUT') }}
            @else
            <form action="{{ route('posts.store') }}" method="post">
            @endif

                {{ csrf_field() }}
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="title"> Título </label>
                        <input type="text" name="title" id="title" class="form-control" placehold="Título" value="{{ $post->title }}">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="category_id"> Categoria </label>
                        <select name="category_id" id="category_id" class="form-control">
                            <option value="0"> Selecionar... </option>
                            @foreach($categories as $category)
                                @if($category->active)
                                    @if($category->id == $post->category_id)
                                        <option value="{{ $category->id }}" selected> {{ $category->name }} </option>
                                    @else
                                        <option value="{{ $category->id }}"> {{ $category->name }} </option>
                                    @endif
                                @endif
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="summary"> Resumo da notícia </label>
                        <textarea name="summary" id="summary" rows="5" class="form-control" placeholder="Digite o resumo da notícia"> {{ $post->summary }} </textarea>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="text"> Texto </label>
                        <textarea name="text" id="text" rows="5" class="form-control" placeholder="Notícia completa"> {{ $post->text }} </textarea>
                    </div>
                </div>
                <button type="submit" class="btn btn-dark"> Salvar </button>
            </form>
        </div>
    </div>
</div>
@endsection