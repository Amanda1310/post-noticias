@extends('partials.layout')

@section('content')
<div class="container">
    <div class="row mt-3">
        <div class="col-12">
            <h1> Notícias </h1>
            <div class="row mb-2">
                @foreach($posts as $post)
                    @if($post->active and $post->category->active)
                    <div class="col-md-6">
                            <div class="card">
                                    <strong class="card-header"> {{$post->category->name}} </strong>
                                    <div class="card-body">
                                    <h3 class="card-title"> {{ $post->title }} </h3>
                                    <div class="mb-1 text-muted"> {{ date("d/m/y"}} </div>
                                    <p class="mb-auto"><em> {{ $post->summary }} </em></p>
                                    <p class="mb-auto"> {{ $post->text }} </p>
                                    <hr>
                              </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
