@extends('partials.layout')

@section('content')
@include('partials.menu')
<div class="container">
    <div class="row mt-2">
        <div class="col-12">
            <h1>Categorias</h1>
            
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Descrição</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                @foreach($categories as $category)
                    @if($category->active == true)
                        <tr>
                            <td> {{ $category->id }} </td>
                            <td> {{ $category->name }} </td>
                            <td> {{ $category->description }} </td>
                            <td>
                                <form action="{{ route('categories.destroy', ['id' => $category->id]) }}" method="post">
                                    {{ method_field('DELETE') }}
                                    {{ csrf_field() }}
                                    <div class="btn-group">
                                        <a href="{{ route('categories.edit', ['id' => $category->id]) }}" class="btn btn-dark"> Editar </a>
                                        <button type="submit" class="btn btn-dark"> Excluir </button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
            <a href="{{ route('categories.create') }}" class="btn btn-dark"> Inserir mais categorias</a>
        </div>
    </div>
</div>
@endsection