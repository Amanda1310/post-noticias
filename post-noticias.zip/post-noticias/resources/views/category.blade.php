@extends('partials.layout')

@section('content')
@include('partials.menu')
<div class="container">
    <div class="row mt-2">
        <div class="col-6">
            <h1>Categorias</h1>
            @include('partials.errors')

            @if($category->id)
            <form action="{{ route('categories.update', ['id' => $category->id]) }}" method="post">
            {{ method_field('PUT') }}
            @else
            <form action="{{ route('categories.store') }}" method="post">
            @endif

                {{ csrf_field() }}
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="name"> Nome </label>
                        <input type="text" name="name" id="name" class="form-control" placehold="Nome da categoria" value="{{ $category->name }}">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="description"> Descrição </label>
                        <input type="text" name="description" id="description" class="form-control" placehold="Descrição da categoria" value="{{ $category->description }}">
                    </div>
                </div>
                <button type="submit" class="btn btn-dark"> Salvar </button>
            </form>
        </div>
    </div>
</div>
@endsection