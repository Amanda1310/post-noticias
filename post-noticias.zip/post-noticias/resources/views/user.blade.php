@extends('partials.layout')

@section('content')
@include('partials.menu')
<div class="container">
    <div class="row mt-3">
        <div class="col-12">
            <h1>Usuários</h1>
        </div>
    </div>
</div>
<div class="container">
    <div class="row mt-3">
        <div class="col-12">
            <h1>Usuários</h1>
        </div>
    </div>
</div>
<div class="container">
    <div class="row mt-3">
        <div class="col-6">
            @include('partials.errors')

            @if($user->id)
            <form action="{{ route('users.update', ['id' => $user->id]) }}" method="post">
            {{ method_field('PUT') }}
            @else
            <form action="{{ route('users.store') }}" method="post">
            @endif
                {{ csrf_field() }}
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="name"> Nome </label>
                        <input type="text" name="name" id="name" class="form-control" placehold="Nome do usuário" value="{{ $user->name }}">
                        <label for="email"> E-mail </label>
                        <input type="text" name="email" id="email" class="form-control" placehold="E-mail do usuário" value="{{ $user->email }}">
                        <label for="password"> Senha (para manter a senha atual, basta deixa a senha em branco) </label>
                        <input type="password" name="password" id="password" class="form-control">
                        <label for="password_confirmation"> Confirmar Senha </label>
                        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-dark"> Salvar </button>
            </form>
        </div>
    </div>
</div>
@endsection