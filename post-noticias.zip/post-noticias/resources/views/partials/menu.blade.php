<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#"></a>
    <a class="navbar-brand" href="#">NOTÍCIAS</a>
    <div class="collapse navbar-collapse" id="nvb">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="navbar-brand" href="{{ route('posts.index') }}"> POSTS </a>
            </li>
            <li class="nav-item">
                <a class="navbar-brand" href="{{ route('categories.index') }}"> CATEGORIAS </a>
            </li>
            <li class="nav-item">
                <a class="navbar-brand" href="{{ route('users.index') }}"> USUÁRIOS </a>
            </li>
            <li class="nav-item">
                <a class="navbar-brand" href="{{ route('logout') }}"> SAIR </a>
            </li>
        </ul>
    </div>
</nav>