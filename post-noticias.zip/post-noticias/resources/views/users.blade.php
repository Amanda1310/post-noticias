@extends('partials.layout')

@section('content')
@include('partials.menu')
<div class="container">
    <div class="row mt-3">
        <div class="col-12">
            <h1>Usuários</h1>
        </div>
    </div>
</div>
<div class="container">
    <div class="row mt-3">
        <div class="col-12">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                @foreach($users as $user)
                    <tr>
                        <td> {{ $user->id }} </td>
                        <td> {{ $user->name }} </td>
                        <td> {{ $user->email }} </td>
                        <td>
                            <form action="{{ route('users.destroy', ['id' => $user->id]) }}" method="post">
                                {{ method_field('DELETE') }}
                                {{ csrf_field() }}
                                <div class="btn-group">
                                    <a href="{{ route('users.edit', ['id' => $user->id]) }}" class="btn btn-dark"> Editar </a>
                                    <button type="submit" class="btn btn-dark" > Excluir </button>
                                </div>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </table>
            <a href="{{ route('users.create') }}" class="btn btn-dark"> Inserir </a>
        </div>
    </div>
</div>
@endsection