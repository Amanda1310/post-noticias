<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

use Validator;

use App\Http\Controllers\Controller;
use App\Post;
use App\Category;

class PostController extends Controller {
    public function index(){
        $posts = Post::all();

        return view('posts', [
            'posts' => $posts
        ]);
    }
    
    public function create(){
        $post = new Post();
        $categories = Category::all();

        return view('post', [
            'post' => $post,
            'categories' => $categories
        ]);
    }

    public function store(Request $request){
        $rules = [
            'category_id' => 'required|exists:categories,id',
            'title' => 'required|min:3|max:50',
            'summary' => 'required|max:255',
            'text' => 'required|min:30'
        ];

        $messages = [
            'category_id.required' => 'Uma categoria deve ser selecionada',
            'category_id.exists' => 'Você deve selecionar uma categoria válida', 
            'title.required' => 'O campo título deve ser preenchido',
            'title.min' => 'O campo título deve ter pelo menos 3 caracteres',
            'title.max' => 'O campo título deve ter no máximo 50 caracteres',
            'summary.required' => 'O campo de resumo deve ser preenchido',
            'summary.max' => 'O campo de resumo deve ter no máximo 255 caracteres',
            'text.required' => 'O campo de texto deve ser preenchido',
            'text.min' => 'O campo de texto deve ter pelo menos 30 caracteres'
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $post = new Post();
        $post->category_id = $request->input('category_id');
        $post->title = $request->input('title');
        $post->summary = $request->input('summary');
        $post->text = $request->input('text');

        $post->save();

        return redirect()->route('posts.index');
    }

    public function edit($id){
        $post = Post::find($id);
        $categories = Category::all();

        return view('post', [
            'post' => $post,
            'categories' => $categories
        ]);
    }

    public function update(Request $request, $id){
        $rules = [
            'category_id' => 'required|exists:categories,id',
            'title' => 'required|min:3|max:50',
            'summary' => 'required|max:255',
            'text' => 'required|min:30'
        ];

        $messages = [
            'category_id.required' => 'Uma categoria deve ser selecionada',
            'category_id.exists' => 'Você deve selecionar uma categoria válida', 
            'title.required' => 'O campo título deve ser preenchido',
            'title.min' => 'O campo título deve ter pelo menos 3 caracteres',
            'title.max' => 'O campo título deve ter no máximo 50 caracteres',
            'summary.required' => 'O campo de resumo deve ser preenchido',
            'summary.max' => 'O campo de resumo deve ter no máximo 255 caracteres',
            'text.required' => 'O campo de texto deve ser preenchido',
            'text.min' => 'O campo de texto deve ter pelo menos 30 caracteres'
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $post = Post::find($id);
        $post->category_id = $request->input('category_id');
        $post->title = $request->input('title');
        $post->summary = $request->input('summary');
        $post->text = $request->input('text');

        $post->save();

        return redirect()->route('posts.index');
    }

    public function destroy($id){
        Post::where('id', $id)->update(array('active' => false));

        return redirect()->route('posts.index');
    }
}